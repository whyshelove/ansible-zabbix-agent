#!/bin/bash
ARGS=("$@")
DISCOVERY_TYPE=$1
REDIS_CLI_DEFAULT_PATH="/usr/bin/redis-cli"
STBDBUF_DEFAULT_PATH="/usr/bin/stdbuf"
# USE FIRST ARGUMENT TO UNDERSTAND WHICH DISCOVERY TO PERFORM
shift
IFS=$'\n'
PASSWORDS=( "$@" )
LIST=$(ps -eo user,args | grep -v grep | grep -E -i -w 'keydb-server|redis-server' | tr -s [:blank:] ":")

# BASH CONFIGURATION
setopt noglob &> /dev/null || true
set -o noglob &> /dev/null || true
set -o pipefail &> /dev/null || true

if [[ " ${ARGS[@]} " =~ " debug " ]]; then
    set -x
fi

# REQUIRED UTILS TO BE ABLE TO RUN
if [[ -e /tmp/redis-cli ]]; then
    REDIS_CLI=$(cat /tmp/redis-cli)
else
    REDIS_CLI=$(locate redis-cli | head -n 1)
    if [[ "$REDIS_CLI" == "" ]]; then
        if [[ -e $REDIS_CLI_DEFAULT_PATH ]]; then
            REDIS_CLI_FILE=$(echo $REDIS_CLI_DEFAULT_PATH > /tmp/redis-cli)
        else
            echo '{"data":[]}'
            exit 1
        fi
    else
        REDIS_CLI_FILE=$(echo $REDIS_CLI > /tmp/redis-cli)
    fi
fi

if [ "$DISCOVERY_TYPE" != "general" ] && [ "$DISCOVERY_TYPE" != "stats" ] && [ "$DISCOVERY_TYPE" != "replication" ]; then
    echo "USAGE: ./zbx_redis_discovery.sh where"
    echo "general - argument generate report with discovered instances"
    echo "stats - generates report for avalable commands"
    echo "replication - generates report for avalable slaves"
    exit 1
fi

# PROBE DISCOVERED REDIS INSTACES - TO GET INSTANCE_META NAME#
discover_redis_instance() {
    HOST=$1
    PORT=$2
    PASSWORD=$3

    ALIVE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" ping 2>/dev/null)

    if [[ $ALIVE != "PONG" ]]; then
        return 1
    else
        INSTANCE_PROCESS_NAME="unknown"
        INSTANCE_PROCESS_PATH="unknown"
        INSTANCE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" info 2>/dev/null | grep config_file | cut -d ":" -f2 | sed 's/.conf//g' | rev | cut -d "/" -f1 | rev | tr -d [:space:] | tr [:lower:] [:upper:])
        # WHEN UNABLE TO IDENTIFY INSTANCE_META NAME BASED ON CONFIG
        if [ "$INSTANCE" = "" ]; then
            INSTANCE_META=$(echo "$HOST:$PORT")
        fi
        FULL_PROCESS=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" info 2>/dev/null | grep executable | cut -d ":" -f2 | tr -d [:space:] )
        if [ "$FULL_PROCESS" != "" ]; then
            INSTANCE_PROCESS_NAME=$(basename $FULL_PROCESS)
            INSTANCE_PROCESS_PATH=$(dirname $FULL_PROCESS)
        fi

    fi

    echo "$INSTANCE;$INSTANCE_PROCESS_NAME;$INSTANCE_PROCESS_PATH"
}

# PROBE DISCOVERED REDIS INSTACES - TO GET RDB DATABASE#
discover_redis_rdb_database() {
    HOST=$1
    PORT=$2
    PASSWORD=$3

    ALIVE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" ping 2>/dev/null)

    if [[ $ALIVE != "PONG" ]]; then
        return 1
    else
        INSTANCE_RDB_PATH=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" config get "dir" 2>/dev/null | cut -d " " -f2 | sed -n 2p)
        INSTANCE_RDB_FILE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" config get "dbfilename" 2>/dev/null | cut -d " " -f2 | sed -n 2p)
    fi

    echo $INSTANCE_RDB_PATH/$INSTANCE_RDB_FILE
}

discover_redis_available_commands() {
    HOST=$1
    PORT=$2
    PASSWORD=$3

    ALIVE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" ping 2>/dev/null)

    if [[ $ALIVE != "PONG" ]]; then
        return 1
    else
        REDIS_COMMANDS=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" info all 2>/dev/null | grep cmdstat | cut -d":" -f1)
    fi

    ( IFS=$'\n'; echo "${REDIS_COMMANDS[*]}" )
}

discover_redis_available_slaves() {
    HOST=$1
    PORT=$2
    PASSWORD=$3

    ALIVE=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" ping 2>/dev/null)

    if [[ $ALIVE != "PONG" ]]; then
        return 1
    else
        REDIS_SLAVES=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" info all 2>/dev/null | grep ^slave | cut -d ":" -f1 | grep [0-1024])
    fi

    ( IFS=$'\n'; echo "${REDIS_SLAVES[*]}" )
}

# GENERATE ZABBIX DISCOVERY JSON REPONSE #
generate_general_discovery_json() {
    HOST=$1
    PORT=$2
    INSTANCE=$3
    RDB_PATH=$4
    PROCESS_NAME=$5
    PROCESS_PATH=$6

    echo -n '{'
    echo -n '"{#HOST}":"'$HOST'",'
    echo -n '"{#PORT}":"'$PORT'",'
    echo -n '"{#INSTANCE}":"'$INSTANCE'",'
    echo -n '"{#RDB_PATH}":"'$RDB_PATH'",'
    echo -n '"{#PROCESS_NAME}":"'$PROCESS_NAME'",'
    echo -n '"{#PROCESS_PATH}":"'$PROCESS_PATH'"'
    echo -n '},'
}

# GENERATE ZABBIX DISCOVERY JSON REPONSE #
generate_commands_discovery_json() {
    HOST=$1
    PORT=$2
    COMMAND=$3
    INSTANCE=$4

    echo -n '{'
    echo -n '"{#HOST}":"'$HOST'",'
    echo -n '"{#PORT}":"'$PORT'",'
    echo -n '"{#COMMAND}":"'$COMMAND'",'
    echo -n '"{#INSTANCE}":"'$INSTANCE'"'
    echo -n '},'
}

# GENERATE ZABBIX DISCOVERY JSON REPONSE #
generate_replication_discovery_json() {
    HOST=$1
    PORT=$2
    SLAVE=$3
    INSTANCE=$4

    echo -n '{'
    echo -n '"{#HOST}":"'$HOST'",'
    echo -n '"{#PORT}":"'$PORT'",'
    echo -n '"{#SLAVE}":"'$SLAVE'",'
    echo -n '"{#INSTANCE}":"'$INSTANCE'"'
    echo -n '},'
}


# GENERATE ALL REPORTS REQUIRED FOR REDIS MONITORING #
generate_redis_stats_report() {
    HOST=$1
    PORT=$2
    PASSWORD=$3

    # REDIS MAIN REPORT - INFO ALL
    local REDIS_REPORT_RESULT="/tmp/redis-$HOST-$PORT"
    local REDIS_REPORT_RESULT_TMP="/tmp/redis-$HOST-$PORT.tmp"
    REDIS_REPORT=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" info all 2>/dev/null > $REDIS_REPORT_RESULT_TMP)
    REDIS_REPORT_RC=$?

    # REDIS SLOW LOG
    local REDIS_SLOWLOG_LEN_RESULT="/tmp/redis-$HOST-$PORT-slowlog-len"
    local REDIS_SLOWLOG_LEN_RESULT_TMP="/tmp/redis-$HOST-$PORT-slowlog-len.tmp"
    REDIS_SLOWLOG_LEN=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" slowlog len 2>/dev/null | cut -d " " -f2 > $REDIS_SLOWLOG_LEN_RESULT_TMP; $REDIS_CLI -h $HOST -p $PORT -a $PASSWORD slowlog reset 2>/dev/null > /dev/null )
    REDIS_SLOWLOG_LEN_RC=$?

    # REDIS SLOW LOG REPORT
    local REDIS_SLOWLOG_RAW_RESULT="/tmp/redis-$HOST-$PORT-slowlog-raw"
    local REDIS_SLOWLOG_RAW_RESULT_TMP="/tmp/redis-$HOST-$PORT-slowlog-raw.tmp"
    REDIS_SLOWLOG_RAW=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" slowlog get 2>/dev/null > $REDIS_SLOWLOG_RAW_RESULT_TMP)
    REDIS_SLOWLOG_RAW_RC=$?

    # REDIS MAX CLIENT REPORT
    local REDIS_MAX_CLIENTS_RESULT="/tmp/redis-$HOST-$PORT-maxclients"
    local REDIS_MAX_CLIENTS_RESULT_TMP="/tmp/redis-$HOST-$PORT-maxclients.tmp"
    REDIS_MAX_CLIENTS=$($REDIS_CLI -h $HOST -p $PORT -a "$PASSWORD" config get *"maxclients"* 2>/dev/null | cut -d " " -f2 | sed -n 2p > $REDIS_MAX_CLIENTS_RESULT_TMP)
    REDIS_MAX_CLIENTS_RC=$?

    if [[ -e $REDIS_REPORT_RESULT_TMP ]] && [[ $REDIS_REPORT_RC -eq 0 ]];then
        REDIS_REPORT_DUMP=$(mv $REDIS_REPORT_RESULT_TMP $REDIS_REPORT_RESULT)
        if [[ $? -ne 0 ]]; then
            return 1
        fi
    fi

    if [[ -e $REDIS_SLOWLOG_LEN_RESULT_TMP ]] && [[ $REDIS_SLOWLOG_LEN -eq 0 ]];then
        REDIS_REPORT_DUMP=$(mv $REDIS_SLOWLOG_LEN_RESULT_TMP $REDIS_SLOWLOG_LEN_RESULT)
        if [[ $? -ne 0 ]]; then
            return 2
        fi
    fi

    if [[ -e $REDIS_MAX_CLIENTS_RESULT_TMP ]] && [[ $REDIS_SLOWLOG_RAW_RC -eq 0 ]];then
        REDIS_REPORT_DUMP=$(mv $REDIS_SLOWLOG_RAW_RESULT_TMP $REDIS_SLOWLOG_RAW_RESULT)
        if [[ $? -ne 0 ]]; then
            return 2
        fi
    fi

    if [[ -e $REDIS_MAX_CLIENTS_RESULT_TMP ]] && [[ $REDIS_MAX_CLIENTS_RC -eq 0 ]];then
        REDIS_REPORT_DUMP=$(mv $REDIS_MAX_CLIENTS_RESULT_TMP $REDIS_MAX_CLIENTS_RESULT)
        if [[ $? -ne 0 ]]; then
            return 2
        fi
    fi

}

# MAIN LOOP #

echo -n '{"data":['
for s in $LIST; do
    HOST=$(echo $s | sed 's/*/127.0.0.1/g' | cut -d":" -f3)
    PORT=$(echo $s | sed 's/*/127.0.0.1/g' | cut -d":" -f4)

    # TRY PASSWORD PER EACH DISCOVERED INSTANCE
    if [[ ${#PASSWORDS[@]} -ne 0 ]]; then
        for (( i=0; i<${#PASSWORDS[@]}; i++ ));
        do
            PASSWORD=${PASSWORDS[$i]}
            INSTANCE_META=$(discover_redis_instance $HOST $PORT $PASSWORD)
            RDB_PATH=$(discover_redis_rdb_database $HOST $PORT $PASSWORD)
            COMMANDS=$(discover_redis_available_commands $HOST $PORT $PASSWORD)
            SLAVES=$(discover_redis_available_slaves $HOST $PORT $PASSWORD)

            if [[ -n $INSTANCE_META ]]; then

                INSTANCE=$(echo $INSTANCE_META | cut -d ";" -f1)
                INSTANCE_PROCESS_NAME=$(echo $INSTANCE_META | cut -d ";" -f2)
                INSTANCE_PROCESS_PATH=$(echo $INSTANCE_META | cut -d ";" -f3)

                # DECIDE WHICH REPORT TO GENERATE FOR DISCOVERY
                if [[ $DISCOVERY_TYPE == "general" ]]; then
                    generate_redis_stats_report $HOST $PORT $PASSWORD
                    generate_general_discovery_json $HOST $PORT $INSTANCE $RDB_PATH $INSTANCE_PROCESS_NAME $INSTANCE_PROCESS_PATH
                elif [[ $DISCOVERY_TYPE == "stats" ]]; then
                    for COMMAND in ${COMMANDS}; do
                        generate_commands_discovery_json $HOST $PORT $COMMAND $INSTANCE
                    done
                elif [[ $DISCOVERY_TYPE == "replication" ]]; then
                    for SLAVE in ${SLAVES}; do
                        generate_replication_discovery_json $HOST $PORT $SLAVE $INSTANCE
                    done
                fi
            fi
        done
    else
        INSTANCE_META=$(discover_redis_instance $HOST $PORT "")
        RDB_PATH=$(discover_redis_rdb_database $HOST $PORT "")
        COMMANDS=$(discover_redis_available_commands $HOST $PORT "")
        SLAVES=$(discover_redis_available_slaves $HOST $PORT "")

        if [[ -n $INSTANCE_META ]]; then

            INSTANCE=$(echo $INSTANCE_META | cut -d ";" -f1)
            INSTANCE_PROCESS_NAME=$(echo $INSTANCE_META | cut -d ";" -f2)
            INSTANCE_PROCESS_PATH=$(echo $INSTANCE_META | cut -d ";" -f3)

            # DECIDE WHICH REPORT TO GENERATE FOR DISCOVERY
            if [[ $DISCOVERY_TYPE == "general" ]]; then
                generate_redis_stats_report $HOST $PORT ""
                generate_general_discovery_json $HOST $PORT $INSTANCE $RDB_PATH $INSTANCE_PROCESS_NAME $INSTANCE_PROCESS_PATH
            elif [[ $DISCOVERY_TYPE == "stats" ]]; then
                for COMMAND in ${COMMANDS}; do
                    generate_commands_discovery_json $HOST $PORT $COMMAND $INSTANCE
                done
            elif [[ $DISCOVERY_TYPE == "replication" ]]; then
                for SLAVE in ${SLAVES}; do
                    generate_replication_discovery_json $HOST $PORT $SLAVE $INSTANCE
                done
            fi
        fi
    fi
    unset
done | sed -e 's:\},$:\}:'
echo -n ']}'
echo ''
unset IFS
